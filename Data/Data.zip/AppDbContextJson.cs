using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using QuanLyThuVien.Api.Models;

namespace QuanLyThuVien.Api.Data;

/// <summary>
/// </summary>
public class AppDbContextJson : DbContext
{
    public AppDbContextJson(DbContextOptions<AppDbContextJson> options) : base(options) { }
    
    // Moi DbSet tuong ung mot BANG trong co so du lieu
    public DbSet<TacGia> TacGia => Set<TacGia>();
    public DbSet<Sach> Sach => Set<Sach>();
    public DbSet<PhieuMuon> PhieuMuon => Set<PhieuMuon>();

    // Khai bao duong dan tuong doi den cac file Json du lieu mau
    private const string pathData = "Data";
    private const string FileTacGia = "seedTacGia.json";
    private const string FileSach = "seedSach.json";
    private const string FilePhieuMuon = "seedPhieuMuon.json";

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // =================================================================
        // Nap du lieu mau tu JSON - HasData
        // Quy tac: co khoa chinh tuong minh, nap bang CHA truoc bang CON
        // Sua JSON xong phai tao migration moi.
        // =================================================================

        // ---- 1. BANG CHA truoc ----
        modelBuilder.Entity<TacGia>().HasData(DocFileJson<TacGia>(FileTacGia));

        // ---- 2. BANG CON sau ----
        modelBuilder.Entity<Sach>().HasData(DocFileJson<Sach>(FileSach));

        // ---- 3. THUC THE GIAO DICH cuoi cung ----
        modelBuilder.Entity<PhieuMuon>().HasData(DocFileJson<PhieuMuon>(FilePhieuMuon));
    }

    // Ham doc du lieu tu file JSON
    private static List<T> DocFileJson<T>(string tenFile)
    {
        string[] duongDanFiles =
        {
            // path: Data/seedSach.json
            Path.Combine(AppContext.BaseDirectory, pathData, tenFile),          
            Path.Combine(Directory.GetCurrentDirectory(), pathData, tenFile)        
        };

        // Tim duong dan file JSON ton tai dau tien trong danh sach duong dan
        var duongDan = duongDanFiles.FirstOrDefault(File.Exists)
            ?? throw new FileNotFoundException($"Khong tim thay '{tenFile}'. Da tim o: " + string.Join(" | ", duongDanFiles));

        // Doc noi dung file JSON va chuyen sang List<T>
        return JsonSerializer.Deserialize<List<T>>(File.ReadAllText(duongDan))
            ?? throw new InvalidOperationException($"File '{tenFile}' rong hoac sai dinh dang.");
    }
}
